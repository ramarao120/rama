package com.java.main;

import java.util.Scanner;

/**
 * @author rama.deshagani
 *
 */
public class NumberToWordConverter {

	 // String array to hold string representation of specialNames 
	    private static final String[] specialNames = {
	        "",
	        " thousand",
	        " million",
	        " billion",
	        " trillion",
	        " quadrillion",
	        " quintillion"
	    };
	    // String array to hold string representation of tensNames  
	    private static final String[] tensNames = {
	        "",
	        " ten",
	        " twenty",
	        " thirty",
	        " forty",
	        " fifty",
	        " sixty",
	        " seventy",
	        " eighty",
	        " ninety"
	    };
	 // String array to hold string representation of numNames  
	    private static final String[] numNames = {
	        "",
	        " one",
	        " two",
	        " three",
	        " four",
	        " five",
	        " six",
	        " seven",
	        " eight",
	        " nine",
	        " ten",
	        " eleven",
	        " twelve",
	        " thirteen",
	        " fourteen",
	        " fifteen",
	        " sixteen",
	        " seventeen",
	        " eighteen",
	        " nineteen"
	    };
	    
	    /**
	     * @param number
	     * @return String of LessThanOneThousand nubers
	     */
	    private String convertLessThanOneThousand(int number) {
	        String current;
	        
	        if (number % 100 < 20){
	            current = numNames[number % 100];
	            number /= 100;
	        }
	        else {
	            current = numNames[number % 10];
	            number /= 10;
	            
	            current = tensNames[number % 10] + current;
	            number /= 10;
	        }
	        if (number == 0) return current;
	        return numNames[number] + " hundred" + current;
	    }
	    
	    /**
	     * @param number
	     * @return string of convention name
	     */
	    public String convert(int number) {

	        if (number == 0) { return "zero"; }
	        
	        String prefix = "";
	        
	        if (number < 0) {
	            number = -number;
	            prefix = "negative";
	        }
	        
	        String current = "";
	        int place = 0;
	        
	        do {
	            int n = number % 1000;
	            if (n != 0){
	                String s = convertLessThanOneThousand(n);
	                current = s + specialNames[place] + current;
	            }
	            place++;
	            number /= 1000;
	        } while (number > 0);
	        
	        return (prefix + current).trim();
	    }
	    
	    public static void main(String[] args) {
	    	int number = 0;
			Scanner scanner = new Scanner(System.in);
			System.out.println("Please type a number(max upto 9 digits)");
			try {
				// read the number
				number = scanner.nextInt();
			
	    	NumberToWordConverter obj = new NumberToWordConverter();
	        
	        System.out.println(number+ "Number in words: " + obj.convert(number));
				}catch (Exception e) {
					System.out.println("Please enter a valid number");
			}
			// close the reader
			scanner.close();
	    	
	    }
	}