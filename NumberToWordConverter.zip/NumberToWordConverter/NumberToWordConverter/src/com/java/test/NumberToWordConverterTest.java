package com.java.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.java.main.NumberToWordConverter;

public class NumberToWordConverterTest {
	 @Test
	  public void NuberToWordTest(int number) {
		
		NumberToWordConverter obj=new NumberToWordConverter();
		assertEquals("ten", true, obj.convert(10));
		
	}
}
